

/*https://www.hanselman.com/blog/MakingNegativeNumbersTurnRedUsingCSSAndJavascript.aspx*/

function MakeNegative() {
        TDs = document.getElementsByTagName('td');
		
        for (var i=0; i<TDs.length; i++) {
                var temp = TDs[i];
                /*if (temp.firstChild.nodeValue.indexOf('-') == 0) temp.className = "negative";*/
				if (temp.innerHTML < 0) temp.className = "negative";
				if (temp.innerHTML > 0) temp.className = "positive";
            }
    };
	
	
$(document).ready( function() {
  	$("table.striped tbody tr").mouseover( function() {
   		$(this).addClass("highlight");
   		}).mouseout( function() {
   			$(this).removeClass("highlight");
   			});
	

			
	$("table.striped tbody tr:odd").addClass("odd");
   	$("table.striped tbody tr:even").addClass("even");
	MakeNegative();
	

	/*
	//All lines below to experiment with ways to show 
	//additional information on a double-clicks
	
	
  	$("table.striped tbody tr").dblclick( function($) {
   		alert(this.childNodes[0].innerHTML);
		alert(this.parentNode.parentNode.childNodes[0].childNodes[0].innerHTML);
		
		
	});
	
  	$("table.striped tbody tr").dblclick( function() {
   		
		alert($(this).parent().parent().find('th:contains("sym")').text());
		alert($(this).parent().parent().find('th:contains("sym")'));
		
	});

	//https://stackoverflow.com/questions/788225/table-row-and-column-number-in-jquery
	$('table.striped tbody tr td').dblclick(function(){
		var col = $(this).parent().children().index($(this));
		var row = $(this).parent().parent().children().index($(this).parent());
		alert('Row: ' + row + ', Column: ' + col);
		
		console.log("clicked");	
		
	});
	
	*/
	
	
   	});
